package com.student.student.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
public class Student {


    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private Long id;


    @NotBlank(message = "Name is mandatory")
    private String name;

    @Email( message = "Invalid emailformat")
    @NotBlank(message = "Email is mandatory")
    private String mail;


    @Pattern(regexp = "(^$|[0-9]{10})")
    private String mob;

    @Lob
    private byte[] pdf;

    @Lob
    private byte[] image;



}
